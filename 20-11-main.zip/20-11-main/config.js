const nameGirl = 'Thầy Cô';
const giftUrl = 'https://bit.ly/m/hackato';
const eventName = 'Chúc Mừng 20-11';
const titleCard = 'Tặng Người lái đò';
const contentCard = 'Nhân Ngày Nhà giáo Việt Nam 20-11, xin chúc cho tất cả các thầy cô giáo trên mọi miền đất nước sức khỏe, hạnh phúc và thật thành công trong sự nghiệp trồng người.';

// phần dưới dành cho các bạn biết code, nếu muốn chỉnh ảnh đơn giản với base64
// Cần hỗ trợ hãy liên hệ: 
// Bio  https://bit.ly/m/hackato

const giftImage = 'images/nhagiaoVN.jpg';
const base64 = '';
const giftImageBase64 = "data:image/png;base64, " + base64;